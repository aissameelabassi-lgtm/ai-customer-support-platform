import os

SYSTEM_PROMPT = """You are Nova, a professional customer support assistant for a demo company.
Be friendly, concise, and useful. If you do not know a company-specific answer, say so
and suggest contacting a human support agent. Never invent prices, policies, or order status."""

def generate_reply(message, history=None):
    """Use OpenAI when an API key is configured; otherwise use a transparent demo fallback."""
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            messages = [{"role": "system", "content": SYSTEM_PROMPT}]
            # Keep a short context window to control cost and protect privacy.
            for item in (history or [])[-10:]:
                if item.get("role") in ("user", "assistant"):
                    messages.append({"role": item["role"], "content": item["content"]})
            if not messages or messages[-1].get("content") != message:
                messages.append({"role": "user", "content": message})
            response = client.chat.completions.create(
                model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
                messages=messages,
                temperature=0.4,
            )
            return response.choices[0].message.content.strip(), "openai"
        except Exception:
            # Do not expose API/provider errors to visitors.
            return fallback_reply(message), "demo"

    return fallback_reply(message), "demo"

def fallback_reply(message):
    text = message.lower()
    if any(word in text for word in ["hello", "hi", "salam", "bonjour", "مرحبا"]):
        return "Hello! 👋 Welcome to our support center. How can I help you today?"
    if any(word in text for word in ["price", "pricing", "cost", "tarif", "ثمن"]):
        return ("Thanks for your interest. I can help with pricing questions, but this demo "
                "workspace does not contain a verified price list yet. Please contact the sales team.")
    if any(word in text for word in ["refund", "return", "remboursement", "رجع"]):
        return ("I can help with a return or refund request. Please share your order reference "
                "and the support team can review the applicable policy.")
    if any(word in text for word in ["order", "delivery", "shipping", "commande", "livraison"]):
        return ("I can help you with an order or delivery question. Please provide your order "
                "reference. This demo is not connected to a live order-management system.")
    if any(word in text for word in ["thank", "merci", "شكرا"]):
        return "You're welcome! Is there anything else I can help you with?"
    return ("Thanks for contacting support. I understand your question. This demo assistant "
            "can answer general support requests; for account-specific information, please "
            "contact a human support agent.")
