# Nova — AI Customer Support Platform

A portfolio-ready mini project demonstrating full-stack development, database design, and optional AI integration.

## Features

- Responsive customer-support chat interface
- Conversation history stored in SQLite
- Admin-style dashboard with conversation/message metrics
- Optional OpenAI API integration
- Demo fallback mode when no API key is configured
- Health-check endpoint at `/health`
- Delete conversation functionality

## Tech stack

- Python + Flask
- Flask-SQLAlchemy + SQLite
- HTML, CSS, Bootstrap 5
- OpenAI API (optional)
- Git / GitHub

## Run locally

1. Install Python 3.10+.
2. Clone the repository:
   ```bash
   git clone https://github.com/YOUR-USERNAME/ai-customer-support-platform.git
   cd ai-customer-support-platform
   ```
3. Create and activate a virtual environment:
   ```bash
   python -m venv .venv
   # Windows:
   .venv\\Scripts\\activate
   # macOS/Linux:
   source .venv/bin/activate
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Create your environment file:
   ```bash
   # Windows PowerShell:
   Copy-Item .env.example .env
   # macOS/Linux:
   cp .env.example .env
   ```
6. (Optional) Add your `OPENAI_API_KEY` to `.env` to enable live AI answers.
7. Start the application:
   ```bash
   python app.py
   ```
8. Open http://127.0.0.1:5000

The app works without an API key in demo mode. Do not commit `.env` or expose API keys in screenshots or source code.

## Deploy

The app can be deployed to a Python host that supports Flask and persistent storage. Configure:
- `SECRET_KEY`
- `DATABASE_URL` (use a persistent database for production)
- `OPENAI_API_KEY` (optional)

For a production deployment, use PostgreSQL rather than local SQLite if the host has ephemeral storage, set `FLASK_DEBUG=false`, and run with Gunicorn.

## Project structure

```text
ai-customer-support-platform/
├── app.py
├── assistant_engine.py
├── models.py
├── requirements.txt
├── Procfile
├── runtime.txt
├── .env.example
├── .gitignore
├── templates/
│   ├── base.html
│   ├── index.html
│   └── chat.html
└── static/
    └── css/
        └── style.css
```

## Architecture

1. Browser sends a message to the Flask application.
2. Flask stores the user message in SQLite.
3. The assistant engine uses OpenAI when configured, otherwise a demo fallback.
4. Flask stores the assistant response and returns the updated conversation.
5. The dashboard reads aggregate data from the database.

## Important portfolio note

This is a demonstrator, not a production customer-support system. Before using it with real customers, add authentication, authorization, rate limiting, data-retention controls, input moderation, monitoring, and a verified company knowledge base. Never upload real customer data to a public demo.

## CV description

**AI-Powered Customer Support Platform — Personal Project**
- Built a full-stack customer-support web application using Python, Flask, and SQLite.
- Integrated an optional LLM-powered response engine through the OpenAI API.
- Designed relational data models to store conversations and messages.
- Developed a responsive dashboard and chat interface.
- Implemented environment-based configuration and a health-check endpoint.
