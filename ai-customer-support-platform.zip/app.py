import os
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from dotenv import load_dotenv
from models import db, Conversation, Message
from assistant_engine import generate_reply

load_dotenv()
app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "change-this-secret-key")
app.config["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY", "")
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL", "sqlite:///support.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)

with app.app_context():
    db.create_all()

@app.route("/")
def index():
    conversations = Conversation.query.order_by(Conversation.updated_at.desc()).limit(8).all()
    total_conversations = Conversation.query.count()
    total_messages = Message.query.count()
    return render_template(
        "index.html",
        conversations=conversations,
        total_conversations=total_conversations,
        total_messages=total_messages,
    )

@app.route("/chat", methods=["GET", "POST"])
def chat():
    if request.method == "POST":
        user_text = request.form.get("message", "").strip()
        conversation_id = request.form.get("conversation_id", type=int)
        if not user_text:
            flash("Please enter a message first.", "warning")
            return redirect(url_for("chat", conversation_id=conversation_id) if conversation_id else url_for("chat"))

        conversation = db.session.get(Conversation, conversation_id) if conversation_id else None
        if conversation is None:
            title = user_text[:55] + ("..." if len(user_text) > 55 else "")
            conversation = Conversation(title=title)
            db.session.add(conversation)
            db.session.flush()

        db.session.add(Message(conversation_id=conversation.id, role="user", content=user_text))
        history = [{"role": m.role, "content": m.content} for m in conversation.messages]
        answer, mode = generate_reply(user_text, history)
        db.session.add(Message(conversation_id=conversation.id, role="assistant", content=answer))
        conversation.updated_at = datetime.utcnow()
        db.session.commit()
        return redirect(url_for("chat", conversation_id=conversation.id, mode=mode))

    conversation_id = request.args.get("conversation_id", type=int)
    conversation = db.session.get(Conversation, conversation_id) if conversation_id else None
    conversations = Conversation.query.order_by(Conversation.updated_at.desc()).all()
    return render_template("chat.html", conversation=conversation, conversations=conversations,
                           mode=request.args.get("mode"))

@app.route("/conversations/<int:conversation_id>/delete", methods=["POST"])
def delete_conversation(conversation_id):
    conversation = db.session.get(Conversation, conversation_id)
    if conversation:
        db.session.delete(conversation)
        db.session.commit()
        flash("Conversation deleted.", "success")
    return redirect(url_for("chat"))

@app.route("/health")
def health():
    return jsonify({"status": "ok", "service": "AI Customer Support", "timestamp": datetime.utcnow().isoformat()})

if __name__ == "__main__":
    app.run(debug=os.getenv("FLASK_DEBUG", "false").lower() == "true")
